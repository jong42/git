import org.apache.spark.mllib.recommendation.MatrixFactorizationModel
import org.apache.spark.rdd.RDD
import org.apache.spark.mllib.recommendation.Rating
import org.apache.spark.mllib.linalg.Vectors
import java.io._

val saveModelPath = "/user/jo45cul/proj/model"
val loadModel = MatrixFactorizationModel.load(sc, saveModelPath)

val dataMoviesPath = "/user/jo45cul/proj/data/movies.csv" // "movieId,title,genres" 
val movienames = sc.textFile(dataMoviesPath).filter(x => !(x contains "movieId,title,genres")
).map(_.split(",") match    {
    case Array (movieId,title,genre) => (movieId.toInt,(title,genre)) 
    case Array (movieId,title1,title2,genre) => (movieId.toInt,(title1,genre))
    case Array (movieId,title1,title2,title3,genre) => (movieId.toInt,(title1,genre))
    case Array (movieId,title1,title2,title3,title4,genre) => (movieId.toInt,(title1,genre))
    case Array (movieId,title1,title2,title3,title4,title5,genre) => (movieId.toInt,(title1,genre))  
})
val allMovieFeatures = sc.parallelize(loadModel.productFeatures.collect().map(x => (x._1, Vectors.dense(x._2))))
val data = loadModel.recommendProductsForUsers(10).map{case (uid, ratings)=> ratings}.flatMap(ratings => ratings)
val movieList = data.map{ case Rating(uid, mid, rate) => (mid,(rate,1))}.reduceByKey {
case ((value1, count1), (value2, count2)) => (value1 + value2, count1 + count2)
}.filter{case(mid,(avg,count)) => count >= 100}.mapValues {case (value, count) =>  (value.toDouble / count.toDouble, count)}
val topList = movieList.join(movienames).map{
case (mid,((avg, count),(title, genre))) => (mid, avg, count ,genre, title)}
// use take because it won't get sorted otherwise
val topCount = topList.sortBy(x => x._3, ascending = false).take(20)
val topAVG = topList.sortBy(x => x._2, ascending = false).take(20)
println("Am meisten empfohlen:")
println("Durchschnitt\t\tAnzahl\t\t\tGenre\t\t\tTitle")
topCount.foreach{case (mid, avg, count, genre, title) => println(avg+" \t\t\t "+"\t\t"+count +"\t\t"+genre+" \t\t\t "+title)}

println("---------------")
println("Beste Ratings:")
println("Durchschnitt\t\tAnzahl\t\t\tGenre\t\t\tTitle")
topAVG.foreach{case (mid, avg, count, genre, title) => println(avg+" \t\t\t "+"\t\t"+count +"\t\t"+genre+" \t\t\t "+title)}
