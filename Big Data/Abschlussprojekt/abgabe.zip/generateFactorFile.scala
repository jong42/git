import org.apache.spark.mllib.recommendation.MatrixFactorizationModel
import org.apache.spark.rdd.RDD
import org.apache.spark.mllib.recommendation.Rating
import org.apache.spark.mllib.linalg.Vectors
import java.io._

val saveModelPath = "/user/jo45cul/proj/model"
val loadModel = MatrixFactorizationModel.load(sc, saveModelPath)

val dataMoviesPath = "/user/jo45cul/proj/data/movies.csv" // "movieId,title,genres" 
val movienames = sc.textFile(dataMoviesPath).filter(x => !(x contains "movieId,title,genres")
).map(_.split(",") match    {
    case Array (movieId,title,genre) => (movieId.toInt,(title,genre)) 
    case Array (movieId,title1,title2,genre) => (movieId.toInt,(title1,genre))
    case Array (movieId,title1,title2,title3,genre) => (movieId.toInt,(title1,genre))
    case Array (movieId,title1,title2,title3,title4,genre) => (movieId.toInt,(title1,genre))
    case Array (movieId,title1,title2,title3,title4,title5,genre) => (movieId.toInt,(title1,genre))  
})
val allMovieFeatures = sc.parallelize(loadModel.productFeatures.collect().map(x => (x._1, Vectors.dense(x._2))))
/*
260,Star Wars: Episode IV - A New Hope (1977),Action|Adventure|Sci-Fi
1196,Star Wars: Episode V - The Empire Strikes Back (1980),Action|Adventure|Sci-Fi
1210,Star Wars: Episode VI - Return of the Jedi (1983),Action|Adventure|Sci-Fi
2628,Star Wars: Episode I - The Phantom Menace (1999),Action|Adventure|Sci-Fi
5378,Star Wars: Episode II - Attack of the Clones (2002),Action|Adventure|Sci-Fi|IMAX
33493,Star Wars: Episode III - Revenge of the Sith (2005),Action|Adventure|Sci-Fi
122886,Star Wars: Episode VII - The Force Awakens (2015),Action|Adventure|Fantasy|Sci-Fi|IMAX
166528,Rogue One: A Star Wars Story (2016),Action|Adventure|Fantasy|Sci-Fi
4993,"Lord of the Rings: The Fellowship of the Ring, The (2001)",Adventure|Fantasy
5952,"Lord of the Rings: The Two Towers, The (2002)",Adventure|Fantasy
7153,"Lord of the Rings: The Return of the King, The (2003)",Action|Adventure|Drama|Fantasy
84954,"Adjustment Bureau, The (2011)",Romance|Sci-Fi|Thriller
364,"Lion King, The (1994)",Adventure|Animation|Children|Drama|Musical|IMAX
148671,Saw (2003),Crime|Horror
39446,Saw II (2005),Horror|Thriller
48877,Saw III (2006),Crime|Horror|Thriller
57421,Hatchet (2006),Comedy|Horror
82366,Hatchet II (2010),Comedy|Horror|Thriller
90430,Carnage (2011),Comedy|Drama
69122,"Hangover, The (2009)",Comedy|Crime
86911,"Hangover Part II, The (2011)",Comedy
102686,"Hangover Part III, The (2013)",Comedy
2571,"Matrix, The (1999)",Action|Sci-Fi|Thriller
6365,"Matrix Reloaded, The (2003)",Action|Adventure|Sci-Fi|Thriller|IMAX
6934,"Matrix Revolutions, The (2003)",Action|Adventure|Sci-Fi|Thriller|IMAX
*/
val movieList = Array(260, 1196, 1210, 2628, 5378, 33493, 122886, 166528, 4993, 5952,  7153, 84954, 364, 8957, 39446, 48877,  57421, 82366, 90430,  69122, 86911, 102686, 2571, 6365,
6934)
val movieRDD = sc.parallelize(movieList).map(x => (x,x)).join(movienames).map{case (mid, (mid2, valX)) => (mid, valX)}
val topCountVec = movieRDD.join(allMovieFeatures).map{case (mid,((title, genre),vector)) => (title,
vector)}.mapValues(x=> (x(0),x(1),x(2),x(3),x(4))).filter{case(a,x) => x != (0.0,0.0,0.0)}.collect()
val pw = new PrintWriter(new File("veclist.txt" ))
for (i <- 0 until topCountVec.size){
    pw.write(topCountVec(i)._1+"::"+topCountVec(i)._2._1+"::"+topCountVec(i)._2._2+"::"+topCountVec(i)._2._3+"::"+topCountVec(i)._2._4+"::"+topCountVec(i)._2._5)
    pw.write("\n")
}
pw.close
