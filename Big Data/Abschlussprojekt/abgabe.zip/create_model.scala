// spark-shell  --conf "spark.rdd.compress=true" --conf "spark.serializer=org.apache.spark.serializer.KryoSerializer"
import org.apache.spark.mllib.recommendation.ALS
import org.apache.spark.mllib.recommendation.MatrixFactorizationModel
import org.apache.spark.mllib.recommendation.Rating
import org.apache.spark.rdd.RDD
import org.apache.spark.mllib.util.MLUtils
import org.apache.spark.storage.StorageLevel._

// Data is stored here
val dataRatingPath = "/user/jo45cul/proj/data/ratings.csv" // "userId,movieId,rating,timestamp"
val dataMoviesPath = "/user/jo45cul/proj/data/movies.csv" // "movieId,title,genres" 
// Temporary directory for checkpoints
sc.setCheckpointDir("/user/jo45cul/proj/Abschlussprojekt/checkpoints")
// Savepoint model
// PLEASE CHANGE
val saveModelPath = "/user/jo45cul/proj/model"

// Setting up our data
val txtFile = sc.textFile(dataRatingPath).filter(x => !(x contains "userId,movieId,rating,timestamp"))
val data = txtFile.map(_.split(",")  match { case Array(uid, mid, rate, tmp) => Rating(uid.toInt, mid.toInt, rate.toDouble)})
//data.cache()

// Filter out MID with less than 1000 ratings and avergae rating of less than 1.5
val boundMID = 100
val minAVG = 0.5
val filterMID = data.map{ case Rating(uid, mid, rate) => (mid,(rate,1))}.reduceByKey { 
case ((value1, count1), (value2, count2)) => (value1 + value2, count1 + count2)
}.filter{case(mid,(avg,count)) => count >= boundMID}.mapValues {case (value, count) =>  value.toDouble / count.toDouble}.filter(x => x._2 > minAVG).sortByKey()

// Filter UIDs with less than 10 ratings
val boundUID = 400
val filterUID = data.map{case Rating(uid, mid, rate) => (mid,(uid,rate.toDouble))}.join(filterMID).map{case(mid,((uid,rate),avg)) => (uid,1)}.reduceByKey(_ + _).filter(x => x._2 >= boundUID).map{case(uid,count) => uid}//Array[(Double, Array[((Double, Double), Double)])]
val filterData  = data.map{case Rating(uid, mid, rate) => (uid, (mid,rate))}.join(filterUID.map(x => (x, x))).map{case(uid,((mid,rate),uid2)) =>
(mid,(uid,rate))}.join(filterMID).map{case (mid,((uid,rate),(avg))) => Rating(uid, mid, rate)}

val randomSeed = 42 * 42
// 70% train, 30 % test
var weights = Array(.7, .3)
val Array(trainData, testData) = filterData.randomSplit(weights, seed = randomSeed)
//trainData.cache()
val conf = sc.hadoopConfiguration
val fs = org.apache.hadoop.fs.FileSystem.get(conf)
val exists = fs.exists(new org.apache.hadoop.fs.Path(saveModelPath))
if(!exists) {
    // Build the recommendation model using ALS
    val alsObj = new ALS()
    val rank = 30 // 10 is recommended, more factors might be need if MSE is too high
    val numIter = 20 // between 10-20 is recommended, more iterations mean better approximation
    val lambda = 0.01 // 0.01 is recommended as regularization parameter (needed to prevent overfitting)
    val numCheckpoints = 5 // Might be too much data to handle, so save it temporary after every fifth iteration
    alsObj.setRank(rank).setIterations(numIter).setLambda(lambda).setNonnegative(true).setSeed(randomSeed).setCheckpointInterval(numCheckpoints).setIntermediateRDDStorageLevel(MEMORY_AND_DISK_SER)
    val model = alsObj.run(trainData)
    model.save(sc, saveModelPath)
}
val model = MatrixFactorizationModel.load(sc, saveModelPath)

def calcMSE(model:MatrixFactorizationModel, checkData:RDD[Rating]) : Double = {
    val checkPred  = model.predict(checkData.map{case Rating(uid, mid, rate) => (uid, mid)}).map{ 
    case Rating(uid, mid, rate) => ((uid, mid), rate)}
    val checkCompare = checkData.map{ case Rating(uid, mid, rate) => ((uid, mid), rate)}.join(checkPred)
    val meanSquareError = checkCompare.map { case ((uid, mid), (rate, pred)) => (rate - pred) * (rate - pred)}.mean()
    return meanSquareError
}

def calcConfMat(model:MatrixFactorizationModel, checkData:RDD[Rating]) : Array[(String, Double)] = {
    val checkPred  = model.predict(checkData.map{case Rating(uid, mid, rate) => (uid, mid)}).map{ 
    case Rating(uid, mid, rate) => ((uid, mid), rate)}
    val checkCompare = checkData.map{ case Rating(uid, mid, rate) => ((uid, mid), rate)}.join(checkPred)
    val filterPred = checkCompare.map { case ((uid, mid), (rate, pred)) => if (pred > 5) (rate, 5.0) else if (pred < 0) (rate, 0.01) else (rate, pred)}
    val filterData = filterPred.map{case(rate, pred) =>
        if(rate > 3.5 && pred > 3.5) ("True positive",1)
        else if (rate > 3.5 && pred <= 3.5) ("False negative",1)
        else if (rate <= 3.5 && pred <= 3.5) ("True negative",1)
        else ("False positive",1)
    }
    val count = filterData.count()
    return filterData.reduceByKey(_ + _).mapValues(x => x.toDouble/count).collect()
}
// Check MSE
val countTrain = trainData.count()
val mseTrain = calcMSE(model, trainData)
val confTrain = calcConfMat(model, trainData)
val trainUsers = model.userFeatures.map{case (uid,features) => (uid, uid)}
val filterTestData = testData.map{case Rating(uid, mid, rate) => (uid, Rating(uid, mid, rate))}.join(trainUsers).map{case (uid, (rate_val, sink)) => rate_val}
val countTest = filterTestData.count()
val mseTest = calcMSE(model, filterTestData)
val confTest = calcConfMat(model, filterTestData)
println("Train Data Count = " + countTrain)
println("Train Data MSE = " + mseTrain)
println("Train Data Confusion Matrix = " + confTrain.mkString)
println("Test Data Count = " + countTest)
println("Test Data MSE = " + mseTest)
println("Test Data Confusion Matrix = " + confTest.mkString)
