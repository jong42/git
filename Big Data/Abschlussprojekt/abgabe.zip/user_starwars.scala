import org.apache.spark.mllib.recommendation.MatrixFactorizationModel
import org.apache.spark.mllib.recommendation.Rating
import org.apache.spark.mllib.optimization.{LBFGS, LeastSquaresGradient, SquaredL2Updater}
import org.apache.spark.mllib.linalg.distributed.RowMatrix
import org.apache.spark.mllib.linalg.DenseMatrix
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.rdd.RDD

val dataMoviesPath = "/user/jo45cul/proj/data/movies.csv" // "movieId,title,genres" 
val movienames = sc.textFile(dataMoviesPath).filter(x => !(x contains "movieId,title,genres")
).map(_.split(",") match    {
    case Array (movieId,title,genre) => (movieId.toInt,(title,genre)) 
    case Array (movieId,title1,title2,genre) => (movieId.toInt,(title1,genre))
    case Array (movieId,title1,title2,title3,genre) => (movieId.toInt,(title1,genre))
    case Array (movieId,title1,title2,title3,title4,genre) => (movieId.toInt,(title1,genre))
    case Array (movieId,title1,title2,title3,title4,title5,genre) => (movieId.toInt,(title1,genre))  
})

def calcUserFeatures( input_val:RDD[(Double, org.apache.spark.mllib.linalg.Vector)]) : DenseMatrix  = {

    val numCorrections  = 10
    val convergenceTol = 1e-5
    val maxNumIterations = 50
    val regParam = 0.1
    val initialWeights = Vectors.dense(new Array[Double](30))

    val (weights, loss) = LBFGS.runLBFGS(
      input_val,
      new LeastSquaresGradient(),
      new SquaredL2Updater(),
      numCorrections,
      convergenceTol,
      maxNumIterations,
      regParam,
      initialWeights
    )
    val vec = new DenseMatrix(1,30,weights.toArray).transpose
    return vec
}
val saveModelPath = "/user/jo45cul/proj/model"
val loadModel = MatrixFactorizationModel.load(sc, saveModelPath)
val love = 5.0
val hate = 0.0
/*
260,Star Wars: Episode IV - A New Hope (1977),Action|Adventure|Sci-Fi
1196,Star Wars: Episode V - The Empire Strikes Back (1980),Action|Adventure|Sci-Fi
1210,Star Wars: Episode VI - Return of the Jedi (1983),Action|Adventure|Sci-Fi
2628,Star Wars: Episode I - The Phantom Menace (1999),Action|Adventure|Sci-Fi
5378,Star Wars: Episode II - Attack of the Clones (2002),Action|Adventure|Sci-Fi|IMAX
33493,Star Wars: Episode III - Revenge of the Sith (2005),Action|Adventure|Sci-Fi
122886,Star Wars: Episode VII - The Force Awakens (2015),Action|Adventure|Fantasy|Sci-Fi|IMAX
166528,Rogue One: A Star Wars Story (2016),Action|Adventure|Fantasy|Sci-Fi
*/
val allMovieFeatures = sc.parallelize(loadModel.productFeatures.collect().map(x => (x._1, Vectors.dense(x._2))))
val randomList = allMovieFeatures.map(x => x._1).takeSample(false,8, seed=42)
val movieList = Array(260,1196,1210,2628,5378,33493,122886,166528)
val movieRDD = sc.parallelize(movieList).map(x => (x,x))
val randomRDD = sc.parallelize(randomList).map(x => (x,x))
val movieFeatures = loadModel.productFeatures.map(x => (x._1.toInt, Vectors.dense(x._2))).join(movieRDD).map{case (mid,(vector, mid2)) => (mid, vector)}
val randomFeatures = loadModel.productFeatures.map(x => (x._1.toInt, Vectors.dense(x._2))).join(randomRDD).map{case (mid,(vector, mid2)) => (mid, vector)}
val randomRates = randomFeatures.map(x => (3.0, x._2))
val userLoveVec = calcUserFeatures(movieFeatures.map(x => (love, x._2)).union(randomRates))
val userHateVec = calcUserFeatures(movieFeatures.map(x => (hate, x._2)).union(randomRates))

val mat = new RowMatrix(allMovieFeatures.map(x => x._2))

val result = mat.multiply(userLoveVec).rows.zipWithIndex.map{case(rate,index) => (index, rate(0))}
val allMovieIdx = allMovieFeatures.zipWithIndex.map{case ((mid,vector),idx) => (idx, mid)}
val resultFilter = result.join(allMovieIdx).map{case (idx, (rate, mid)) => (rate, mid)}.filter{case(rate, mid) => !movieList.contains(mid)}
val top10Love = sc.parallelize(resultFilter.sortByKey(ascending = false).take(10)).map{case (avg, mid) => (mid, avg)}.join(movienames).map{
case (mid,(avg,(title, genre))) => (avg, genre, title)}.sortBy(x => x._1, ascending=false)

val result = mat.multiply(userHateVec).rows.zipWithIndex.map{case(rate,index) => (index, rate(0))}
val allMovieIdx = allMovieFeatures.zipWithIndex.map{case ((mid,vector),idx) => (idx, mid)}
val resultFilter = result.join(allMovieIdx).map{case (idx, (rate, mid)) => (rate, mid)}.filter{case(rate, mid) => !movieList.contains(mid)}
val top10Hate = sc.parallelize(resultFilter.sortByKey(ascending = false).take(10)).map{case (avg, mid) => (mid, avg)}.join(movienames).map{
case (mid,(avg,(title, genre))) => (avg, genre, title)}.sortBy(x => x._1, ascending=false)

println("Top 10 Filme fuer Star Wars Liebhaber:")
println("Durchschnitt\t\t\tGenre\t\t\tTitle")
top10Love.collect().foreach{case (avg, genre, title) => println(avg+" \t\t\t "+genre+" \t\t\t "+title)}
println("-----------------------------")
println("Top 10 Filme fuer Personen welche Star Wars gar nicht moegen:")
println("Durchschnitt\t\t\tGenre\t\t\tTitle")
top10Hate.collect().foreach{case (avg, genre, title) => println(avg+" \t\t\t "+genre+" \t\t\t "+title)}
