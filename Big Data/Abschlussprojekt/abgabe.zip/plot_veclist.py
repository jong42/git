#!/usr/bin/env python
from adjustText import adjust_text
import numpy as np
import matplotlib.pyplot as plt
import numpy as np
import sys
import matplotlib.cm as cm
import pandas as pd

if len(sys.argv)==2:
  with open(sys.argv[1]) as f:
    data = f.read()
else:
  print("usage: plot.py DATAFILE")
  sys.exit(1)

data = data.splitlines()


for i in range(1,6)
  for k in range(1,6):
    label = [int(i.split("::")[0]) for i in data]
    names = [i.split("::")[1] for i in data]
    x = [float(i.split("::")[i+1]) for i in data]
    y = [float(i.split("::")[k+1]) for i in data]

    df = pd.DataFrame(dict(x=x, y=y, name=names, label=label))
    groups = df.groupby('label')

    label_names = ["Lord of the Ring", "Carnage", "Matrix", "Hatchet", "Saw", "Saw", "Hangover", "Matrix",
    "Star Wars Prequels", "Star Wars Classics", "Star Wars New","","","Hangover"]
    fig, ax = plt.subplots()
# define the colormap
    cmap = plt.cm.gist_rainbow
# extract all colors from the .jet map
    cmap = [cmap(i) for i in range(cmap.N)]
    print(len(cmap))

    ax.margins(0.05)
    for name, group in groups:
      ax.plot(group.x, group.y, c = cmap[name*18],marker='o', linestyle='', ms=12, label=label_names[name])

    ax.legend()
    ax.set_xlabel("Faktor 3")
    ax.set_ylabel("Faktor 4")
    fig.set_size_inches(10, 5)
    fig.savefig("fac%s-fac%s.png"%(i,k), dpi=100)
