// spark-shell  --conf "spark.rdd.compress=true" --conf "spark.serializer=org.apache.spark.serializer.KryoSerializer"
import org.apache.spark.mllib.recommendation.ALS
import org.apache.spark.mllib.recommendation.MatrixFactorizationModel
import org.apache.spark.mllib.recommendation.Rating
import org.apache.spark.rdd.RDD
import org.apache.spark.mllib.util.MLUtils
import org.apache.spark.storage.StorageLevel._

// Data is stored here
val dataRatingPath = "/user/jo45cul/proj/data/ratings.csv" // "userId,movieId,rating,timestamp"
val dataMoviesPath = "/user/jo45cul/proj/data/movies.csv" // "movieId,title,genres" 

// Setting up our data
val txtFile = sc.textFile(dataRatingPath).filter(x => !(x contains "userId,movieId,rating,timestamp"))
val data = txtFile.map(_.split(",")  match { case Array(uid, mid, rate, tmp) => Rating(uid.toInt, mid.toInt, rate.toDouble)})
val movienames = sc.textFile(dataMoviesPath).filter(x => !(x contains "movieId,title,genres")
).map(_.split(",") match    {
    case Array (movieId,title,genre) => (movieId.toInt,(title,genre)) 
    case Array (movieId,title1,title2,genre) => (movieId.toInt,(title1,genre))
    case Array (movieId,title1,title2,title3,genre) => (movieId.toInt,(title1,genre))
    case Array (movieId,title1,title2,title3,title4,genre) => (movieId.toInt,(title1,genre))
    case Array (movieId,title1,title2,title3,title4,title5,genre) => (movieId.toInt,(title1,genre))  
})


//data.cache()

// Filter out MID with less than 1000 ratings and avergae rating of less than 1.5
val boundMID = 100
val minAVG = 0.5
val filterMID = data.map{ case Rating(uid, mid, rate) => (mid,(rate,1))}.reduceByKey { 
case ((value1, count1), (value2, count2)) => (value1 + value2, count1 + count2)
}.filter{case(mid,(avg,count)) => count >= boundMID}.mapValues {case (value, count) =>  value.toDouble / count.toDouble}.filter(x => x._2 > minAVG).sortByKey()


// Filter UIDs with less than 10 ratings
val boundUID = 400
val filterUID = data.map{case Rating(uid, mid, rate) => (mid,(uid,rate.toDouble))}.join(filterMID).map{case(mid,((uid,rate),avg)) => (uid,1)}.reduceByKey(_ + _).filter(x => x._2 >= boundUID).map{case(uid,count) => uid}//Array[(Double, Array[((Double, Double), Double)])]
val filterData  = data.map{case Rating(uid, mid, rate) => (uid, (mid,rate))}.join(filterUID.map(x => (x, x))).map{case(uid,((mid,rate),uid2)) =>
(mid,(uid,rate))}.join(filterMID)


val moviesD = data.map{ case Rating(uid, mid, rate) => (mid,(rate,1))}.reduceByKey { 
case ((value1, count1), (value2, count2)) => (value1 + value2, count1 + count2)
}.mapValues {case (value, count) =>  value.toDouble / count.toDouble}
val avgD = moviesD.map{case (mid, avg) => avg }.mean()
val userD = data.map{case Rating(uid, mid, rate) => (uid,1) }.reduceByKey(_ + _).map{case (uid,count) => count}
val countUserD = userD.count()
val userMaxD = userD.max()
val userMinD = userD.min()
val userMeanD = userD.mean()
val countD = data.count()
val countMoviesD = moviesD.count()

val avgFD = filterMID.map{case (mid, avg) => avg }.mean()
val topFD = sc.parallelize(filterData.map{case (mid,((uid,rate),(avg))) => (avg, mid) }.distinct.sortByKey(ascending = false).take(10)).map{case (avg, mid) => (mid, avg)}.join(movienames).map{
case (mid,(avg,(title, genre))) => (avg, genre, title)}.sortBy(x => x._1, ascending=false)
val userFD = filterData.map{case (mid,((uid,rate),(avg))) => (uid,1) }.reduceByKey(_ + _).map{case (uid,count) => count}
val userMaxFD = userFD.max()
val userMinFD = userFD.min()
val userMeanFD = userFD.mean()
val countUserFD = userFD.count()
val countFD = filterData.count()
val countMoviesFD = filterMID.count()
println("------------------")
println("Gesamter Datensatz")
println("Anzahl Ratings: " + countD)
println("Anzahl User: " + countUserD)
println("Anzahl Filme: " + countMoviesD)
println("Durschnittliche Filmbewertung: " + avgD)
println("Max. Userbewertungen: " + userMaxD)
println("Min. Userbewertungen: " + userMinD)
println("Durchnittliche Anzahl Userbewertungen: " + userMeanD)
println("------------------")
println("Verwendeter Datensatz")
println("Anzahl Ratings: " + countFD)
println("Anzahl User: " + countUserFD)
println("Anzahl Filme: " + countMoviesFD)
println("Durschnittliche Filmbewertung: " + avgFD)
println("Max. Userbewertungen: " + userMaxFD)
println("Min. Userbewertungen: " + userMinFD)
println("Durchnittliche Anzahl Userbewertungen: " + userMeanFD)
println("Top 10 Filme:")
println("Durchschnitt\t\t\tGenre\t\t\tTitle")
topFD.collect().foreach{case (avg, genre, title) => println(avg+" \t\t\t "+genre+" \t\t\t "+title)}
